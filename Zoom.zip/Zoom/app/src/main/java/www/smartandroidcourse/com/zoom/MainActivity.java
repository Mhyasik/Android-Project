package www.smartandroidcourse.com.zoom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ZoomControls;

public class MainActivity extends AppCompatActivity {
    RelativeLayout relative;
    ZoomControls zoom;
    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        relative = (RelativeLayout)findViewById(R.id.relative);
        image = (ImageView)findViewById(R.id.imageView);
        zoom = new ZoomControls(MainActivity.this);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams
                ((int) RelativeLayout.LayoutParams.WRAP_CONTENT, (int)
                        RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.bottomMargin = 40;
        zoom.setLayoutParams(params);
        relative.addView(zoom);
        zoom.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
// TODO Auto-generated method stub
                float x = image.getScaleX();
                float y = image.getScaleY();
                image.setScaleX((float) (x+1));
                image.setScaleY((float) (y+1));
            }
        });
        zoom.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
// TODO Auto-generated method stub
                float x = image.getScaleX();
                float y = image.getScaleY();
                image.setScaleX((float) (x-1));
                image.setScaleY((float) (y-1));
            }
        });
    }
}