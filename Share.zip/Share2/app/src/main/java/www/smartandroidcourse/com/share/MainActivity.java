package www.smartandroidcourse.com.share;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button share=(Button)findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT," Download Smart Android Course at https://play.google.com/store/apps/details?id=colorsfx.smart.android.courses&hl=en");
                intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "SMART ANDROID COURSE");
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });
    }
}
