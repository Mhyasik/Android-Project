package www.colorsfx.com.otpverify;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Toast;

import com.hololo.library.otpview.OTPListener;
import com.hololo.library.otpview.OTPView;

public class OtpData extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_data);

        OTPView otpView = (OTPView) findViewById(R.id.otpView);
        otpView.setInputType(InputType.TYPE_CLASS_NUMBER)
                .setViewsPadding(16)
                .setListener(new OTPListener() {
                    @Override
                    public void otpFinished(String otp) {
                        Toast.makeText(OtpData.this, "OTP finished, the otp is " + otp, Toast.LENGTH_SHORT).show();
                    }
                })
                .fillLayout();

        otpView.setListener(new OTPListener() {
            @Override
            public void otpFinished(String otp) {
                Toast.makeText(OtpData.this, "OTP finished, the otp is " + otp, Toast.LENGTH_SHORT).show();
            }
        });

    }
}
