package www.colorsfx.com.otpverify;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, CATEGORIES);
        AutoCompleteTextView autotext = (AutoCompleteTextView)
                findViewById(R.id.country_code);

        autotext.setAdapter(adapter);


        FloatingActionButton next=(FloatingActionButton)findViewById(R.id.fab);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),OtpData.class);
                startActivity(i);


            }
        });
    }

    private static final String[] CATEGORIES = new String[] {
            "India (+91)", "Italy (39)", "Russia (7)", "United Kingdom (44)", "United States (1)", "United Arab Emirates (971)"};
}
